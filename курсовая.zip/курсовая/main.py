"""
Metro — приложение для построения маршрутов в метро.
Интерфейс на Tkinter: карта линий метро + панель поиска маршрута
(«Откуда» / «Куда» с подсказками при вводе, кнопки «Быстрее / Меньше остановок / Дешевле»).
У каждого поля есть кнопка-булавка: можно указать произвольную точку на карте;
маршрут тогда идёт от ближайшей станции к точке чёрным пунктиром.

Схема (станции и линии) лежит в metro_data.py — оба файла должны быть в одной папке.

Запуск:
    python main.py
"""

import heapq
import json
import math
import os
import tkinter as tk
import tkinter.font as tkfont
from collections import deque
from tkinter import ttk, messagebox

from metro_data import STATIONS, LINES, RINGS, LINE_INFO, WORLD_W, WORLD_H

# ------------------------------------------------------------------
# 1. ДАННЫЕ О МЕТРО: цвета, названия, цены
# ------------------------------------------------------------------

LINE_COLORS = {k: v[0] for k, v in LINE_INFO.items()}
LINE_NAMES = {k: v[1] for k, v in LINE_INFO.items()}
DEFAULT_FARES = {k: v[2] for k, v in LINE_INFO.items()}
LINE_FARES = dict(DEFAULT_FARES)          # текущие цены (меняются в настройках)

# «отпечаток» схемы: если схема сменилась, сохранённые цены от старой схемы не применяются
MAP_ID = "|".join(f"{k}:{v[1]}" for k, v in LINE_INFO.items())

# названия цветов линий (для окна настроек) берём прямо из схемы:
# "Бирюзовая (10)" -> "Бирюзовая"
COLOR_NAMES = {k: v[1].split(" (")[0] for k, v in LINE_INFO.items()}

DEFAULT_TRANSFER_MIN = 3
EDGE_SPEED = 80          # пикселей схемы за минуту: длина перегона -> время
EDGE_MIN_MIN = 1         # минимальное время перегона, мин
DEFAULT_DWELL_MIN = 0.5
DEFAULT_ALGORITHM = "dijkstra"
SETTINGS = {"transfer_min": DEFAULT_TRANSFER_MIN, "dwell_min": DEFAULT_DWELL_MIN,
            "algorithm": DEFAULT_ALGORITHM}

SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.json")


def load_settings():
    """Читает сохранённые цены, время пересадки/стоянки и алгоритм из settings.json."""
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("map_id") == MAP_ID:          # цены от другой схемы не применяем
            for key, val in data.get("fares", {}).items():
                if key in LINE_FARES and isinstance(val, (int, float)) and val >= 0:
                    LINE_FARES[key] = int(val)
        val = data.get("transfer_min")
        if isinstance(val, (int, float)) and val >= 0:
            SETTINGS["transfer_min"] = float(val)
        val = data.get("dwell_min")
        if isinstance(val, (int, float)) and val >= 0:
            SETTINGS["dwell_min"] = float(val)
        algo = data.get("algorithm")
        if algo in ALGORITHMS:
            SETTINGS["algorithm"] = algo
    except (OSError, ValueError, AttributeError):
        pass


def save_settings():
    """Сохраняет цены, время пересадки/стоянки и алгоритм в settings.json."""
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump({"map_id": MAP_ID,
                       "fares": LINE_FARES,
                       "transfer_min": SETTINGS["transfer_min"],
                       "dwell_min": SETTINGS["dwell_min"],
                       "algorithm": SETTINGS["algorithm"]},
                      f, ensure_ascii=False, indent=2)
    except OSError as exc:
        messagebox.showwarning("Metro", f"Не удалось сохранить настройки:\n{exc}")


CORNER = 28                        # радиус скругления изгибов линий


def _round_path(pts, corner=CORNER, steps=8):
    """Скругляет изломы ломаной (квадратичные кривые Безье в вершинах)."""
    if len(pts) < 3:
        return list(pts)
    out = [pts[0]]
    for i in range(1, len(pts) - 1):
        p0, p1, p2 = pts[i - 1], pts[i], pts[i + 1]
        l1, l2 = math.dist(p0, p1), math.dist(p1, p2)
        if l1 == 0 or l2 == 0:
            out.append(p1)
            continue
        t = min(corner, 0.45 * l1, 0.45 * l2)
        a = (p1[0] + (p0[0] - p1[0]) * t / l1, p1[1] + (p0[1] - p1[1]) * t / l1)
        b = (p1[0] + (p2[0] - p1[0]) * t / l2, p1[1] + (p2[1] - p1[1]) * t / l2)
        for j in range(steps + 1):
            u = j / steps
            out.append(((1 - u) ** 2 * a[0] + 2 * (1 - u) * u * p1[0] + u * u * b[0],
                        (1 - u) ** 2 * a[1] + 2 * (1 - u) * u * p1[1] + u * u * b[1]))
    out.append(pts[-1])
    return out


def _arc_path(p_from, p_to, ring):
    """Дуга кольцевой линии радиуса R между двумя станциями (по окружности)."""
    cx, cy, R = ring
    a1 = math.atan2(-(p_from[1] - cy), p_from[0] - cx)
    a2 = math.atan2(-(p_to[1] - cy), p_to[0] - cx)
    d = (a2 - a1 + math.pi) % (2 * math.pi) - math.pi
    n = max(2, int(abs(d) / 0.06) + 1)
    mid = [(cx + R * math.cos(a1 + d * j / n), cy - R * math.sin(a1 + d * j / n))
           for j in range(1, n)]
    return [p_from] + mid + [p_to]


def _offset_flat(flat_pts, d):
    """Параллельная ломаная со смещением d пикселей (плоский список [x1, y1, x2, y2, ...])."""
    pts = [(flat_pts[i], flat_pts[i + 1]) for i in range(0, len(flat_pts), 2)]
    clean = [pts[0]]
    for p in pts[1:]:
        if math.dist(p, clean[-1]) > 0.01:
            clean.append(p)
    pts = clean
    if len(pts) < 2:
        return []
    normals = []
    for i in range(len(pts) - 1):
        dx, dy = pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]
        ln = math.hypot(dx, dy)
        normals.append((-dy / ln, dx / ln))
    out = []
    for i, p in enumerate(pts):
        k = 1.0
        if i == 0:
            n = normals[0]
        elif i == len(pts) - 1:
            n = normals[-1]
        else:
            n1, n2 = normals[i - 1], normals[i]
            nx, ny = n1[0] + n2[0], n1[1] + n2[1]
            ln = math.hypot(nx, ny)
            if ln < 1e-6:
                n = n1
            else:
                n = (nx / ln, ny / ln)
                k = 1 / max(0.5, n[0] * n1[0] + n[1] * n1[1])   # компенсация на изгибах
        out += [p[0] + n[0] * d * k, p[1] + n[1] * d * k]
    return out


def _darken(hex_color, factor=0.35):
    """Возвращает более тёмный оттенок цвета (#RRGGBB)."""
    r, g, b = (int(hex_color[i:i + 2], 16) for i in (1, 3, 5))
    return "#{:02X}{:02X}{:02X}".format(int(r * factor), int(g * factor), int(b * factor))


def _build_network():
    """Из описания линий собираем рёбра графа (время ~ длина перегона) и пути для рисования."""
    edges, paths = [], {}
    for key, seq in LINES.items():
        last, bends = None, []
        for item in seq:
            if isinstance(item, str):
                if last is not None:
                    if key in RINGS:
                        path = _arc_path(STATIONS[last], STATIONS[item], RINGS[key])
                    else:
                        path = _round_path([STATIONS[last]] + bends + [STATIONS[item]])
                    length = sum(math.dist(path[i], path[i + 1]) for i in range(len(path) - 1))
                    # время перегона пропорционально его длине (с точностью до 0,5 мин):
                    # так «густые» участки с частыми станциями быстрые, но в них много остановок
                    t = max(EDGE_MIN_MIN, round(length / EDGE_SPEED / 0.5) * 0.5)
                    edges.append((last, item, t, key))
                    paths[(last, item, key)] = path
                    paths[(item, last, key)] = path[::-1]
                last, bends = item, []
            else:
                bends.append(item)
    return edges, paths


# рёбра: (станция1, станция2, время_мин, линия)
EDGES, EDGE_PATHS = _build_network()

# adjacency list: station -> [(neighbour, time, line)]
ADJ = {name: [] for name in STATIONS}
for a, b, t, ln in EDGES:
    ADJ[a].append((b, t, ln))
    ADJ[b].append((a, t, ln))

STATION_LINES = {name: set() for name in STATIONS}
for a, b, t, ln in EDGES:
    STATION_LINES[a].add(ln)
    STATION_LINES[b].add(ln)

WALK_SPEED = 20                       # пикселей схемы в минуту пешком (подберите под свою схему)
CUSTOM_LABEL = "Моё местоположение"


def nearest_station(p):
    """Ближайшая к точке p (в координатах схемы) станция."""
    return min(STATIONS, key=lambda n: math.dist(STATIONS[n], p))


# ------------------------------------------------------------------
# 2. ПОИСК МАРШРУТА
# ------------------------------------------------------------------

ALGORITHMS = {}


def register_algorithm(key, name, desc=""):
    def deco(func):
        ALGORITHMS[key] = {"name": name, "desc": desc, "func": func}
        return func
    return deco


@register_algorithm("dijkstra", "Алгоритм № 1",
                    "Выбирает вершину с минимальным накопленным весом и проверяет, "
                    "можно ли найти более короткий путь к соседним вершинам.")
def route_dijkstra(start, end, mode="fast"):
    """
    mode: 'fast' - минимум времени; 'stops' - минимум остановок (станций);
          'cheap' - минимум стоимости (сумма цен линий, по которым едем).
    """
    if start == end:
        return {"legs": [], "time": 0, "transfers": 0, "price": 0, "stations": [start]}

    INF = float("inf")
    best_cost = {(start, None): (0, 0)}
    prev = {}

    pq = [(0, 0, start, None)]
    while pq:
        p, s, station, line = heapq.heappop(pq)
        if (p, s) != best_cost.get((station, line), (INF, INF)):
            continue

        for nb, w, eline in ADJ[station]:
            np_, ns_ = _edge_cost(mode, p, s, line, eline, w)
            state = (nb, eline)
            if (np_, ns_) < best_cost.get(state, (INF, INF)):
                best_cost[state] = (np_, ns_)
                prev[state] = (station, line, eline, w)
                heapq.heappush(pq, (np_, ns_, nb, eline))

    return _finish_route(start, end, best_cost, prev)


def _edge_cost(mode, p, s, line, eline, w):
    """Новая пара (главный критерий, вторичный) при переходе по перегону w на линии eline."""
    is_transfer = 1 if (line is not None and eline != line) else 0
    dwell = SETTINGS["dwell_min"] if line is not None else 0   # стоянка на промежуточной станции
    step = w + dwell
    if mode == "fast":
        return p + step + is_transfer * SETTINGS["transfer_min"], s
    if mode == "stops":
        # главный критерий — число проезжаемых станций, при равенстве — время (с пересадками)
        return p + 1, s + step + is_transfer * SETTINGS["transfer_min"]
    boarding = (line is None) or (eline != line)            # mode == "cheap"
    return (p + (LINE_FARES[eline] if boarding else 0),
            s + step + is_transfer * SETTINGS["transfer_min"])


def _finish_route(start, end, best_cost, prev):
    """Выбирает лучшее конечное состояние, восстанавливает путь и считает итоги."""
    INF = float("inf")
    best_state, best_val = None, (INF, INF)
    for (station, line), val in best_cost.items():
        if station == end and val < best_val:
            best_state, best_val = (station, line), val
    if best_state is None:
        return None

    legs, state = [], best_state
    while state in prev:
        pstation, pline, eline, w = prev[state]
        legs.append((pstation, state[0], eline, w))
        state = (pstation, pline)
    legs.reverse()

    total_time = transfers = price = 0
    prev_line = None
    stations_path = [legs[0][0]] if legs else [start]
    for i, (u, v, line, w) in enumerate(legs):
        total_time += w
        if i > 0:
            total_time += SETTINGS["dwell_min"]          # стоянка на станции u
        if line != prev_line:
            price += LINE_FARES[line]
            if prev_line is not None:
                transfers += 1
                total_time += SETTINGS["transfer_min"]
        prev_line = line
        stations_path.append(v)

    return {"legs": legs, "time": round(total_time), "transfers": transfers,
            "price": price, "stations": stations_path}


@register_algorithm("astar", "Алгоритм № 2",
                    "Выбирает вершину с учётом накопленного веса и предполагаемого "
                    "расстояния до конечной вершины, чтобы быстрее найти оптимальный путь.")
def route_astar(start, end, mode="fast"):
    if start == end:
        return {"legs": [], "time": 0, "transfers": 0, "price": 0, "stations": [start]}

    INF = float("inf")
    ex, ey = STATIONS[end]

    def h(station):
        if mode != "fast":
            return 0.0
        x, y = STATIONS[station]
        return math.hypot(x - ex, y - ey) / 60

    best_cost = {(start, None): (0, 0)}
    prev = {}
    pq = [(h(start), 0, 0, start, None)]          # (f, вторичный, g, станция, линия)
    best_end = INF

    while pq:
        f, s, p, station, line = heapq.heappop(pq)
        if f > best_end:
            break
        if (p, s) != best_cost.get((station, line), (INF, INF)):
            continue
        if station == end:
            best_end = min(best_end, p)

        for nb, w, eline in ADJ[station]:
            np_, ns_ = _edge_cost(mode, p, s, line, eline, w)
            state = (nb, eline)
            if (np_, ns_) < best_cost.get(state, (INF, INF)):
                best_cost[state] = (np_, ns_)
                prev[state] = (station, line, eline, w)
                heapq.heappush(pq, (np_ + h(nb), ns_, np_, nb, eline))

    return _finish_route(start, end, best_cost, prev)


@register_algorithm("bellman_ford", "Алгоритм № 3",
                    "Последовательно проверяет пути между вершинами и уменьшает их веса, "
                    "если находит более выгодный маршрут.")
def route_bellman_ford(start, end, mode="fast"):
    if start == end:
        return {"legs": [], "time": 0, "transfers": 0, "price": 0, "stations": [start]}

    INF = float("inf")
    start_state = (start, None)
    best_cost = {start_state: (0, 0)}
    prev = {}
    queue = deque([start_state])
    in_queue = {start_state}

    while queue:
        state = queue.popleft()
        in_queue.discard(state)
        station, line = state
        p, s = best_cost[state]

        for nb, w, eline in ADJ[station]:
            np_, ns_ = _edge_cost(mode, p, s, line, eline, w)
            nstate = (nb, eline)
            if (np_, ns_) < best_cost.get(nstate, (INF, INF)):
                best_cost[nstate] = (np_, ns_)
                prev[nstate] = (station, line, eline, w)
                if nstate not in in_queue:
                    queue.append(nstate)
                    in_queue.add(nstate)

    return _finish_route(start, end, best_cost, prev)


def find_route(start, end, mode="fast"):
    """Запускает алгоритм, выбранный в настройках."""
    algo = ALGORITHMS.get(SETTINGS["algorithm"]) or ALGORITHMS[DEFAULT_ALGORITHM]
    return algo["func"](start, end, mode)


# Настройки читаем после того, как зарегистрированы все алгоритмы
load_settings()


# ------------------------------------------------------------------
# 3. КАСТОМНЫЕ КНОПКИ (скруглённые, с иконками) И ПОЛЕ ВВОДА СТАНЦИИ
# ------------------------------------------------------------------

def _round_rect(cv, x1, y1, x2, y2, r, **kw):
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
           x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
           x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return cv.create_polygon(pts, smooth=True, **kw)


def _clean_round_rect(cv, x1, y1, x2, y2, r, steps=5, **kw):
    """Скруглённый прямоугольник из точек дуг (без «хвостиков» в углах)."""
    pts = []
    for cx_, cy_, a0 in ((x2 - r, y1 + r, -90), (x2 - r, y2 - r, 0),
                         (x1 + r, y2 - r, 90), (x1 + r, y1 + r, 180)):
        for i in range(steps + 1):
            a = math.radians(a0 + 90 * i / steps)
            pts += [cx_ + r * math.cos(a), cy_ + r * math.sin(a)]
    return cv.create_polygon(pts, joinstyle="round", **kw)


def _draw_icon(cv, kind, cx, cy, color, bg="white"):
    """Простые иконки, нарисованные примитивами канваса."""
    cx, cy = round(cx), round(cy)
    if kind == "clock":
        cv.create_oval(cx - 16, cy - 16, cx + 16, cy + 16, outline=color, width=2)
        cv.create_line(cx, cy, cx, cy - 10, fill=color, width=2, capstyle="round")
        cv.create_line(cx, cy, cx + 7, cy + 4, fill=color, width=2, capstyle="round")
    elif kind == "bus":
        cv.create_arc(cx - 18, cy - 16, cx + 18, cy + 20, start=-45, extent=270,
                      style="arc", outline=color, width=2)
        _clean_round_rect(cv, cx - 8, cy - 9, cx + 8, cy + 10, 4, steps=6,
                          outline=color, fill="", width=2)
        cv.create_line(cx - 3, cy - 6, cx + 3, cy - 6, fill=color, width=1)
        cv.create_rectangle(cx - 6, cy - 4, cx + 6, cy + 1, outline=color, fill="", width=1)
        cv.create_oval(cx - 7, cy + 3, cx - 3, cy + 7, outline=color, fill="", width=1)
        cv.create_oval(cx + 3, cy + 3, cx + 7, cy + 7, outline=color, fill="", width=1)
        cv.create_line(cx - 4, cy + 10, cx - 8, cy + 16, fill=color, width=2, capstyle="round")
        cv.create_line(cx + 4, cy + 10, cx + 8, cy + 16, fill=color, width=2, capstyle="round")
    elif kind == "pin":
        cv.create_polygon(cx, cy + 10, cx - 6, cy - 2, cx + 6, cy - 2,
                          fill=color, outline=color)
        cv.create_oval(cx - 6, cy - 10, cx + 6, cy + 2, fill=color, outline=color)
        cv.create_oval(cx - 2, cy - 6, cx + 2, cy - 2, fill=bg, outline=bg)
    elif kind == "coin":
        cv.create_oval(cx - 16, cy - 16, cx + 16, cy + 16, outline=color, width=2)
        cv.create_text(cx, cy, text="$", fill=color, font=("Segoe UI", 15, "bold"))


class RoundedButton(tk.Canvas):
    """Кнопка со скруглёнными углами; может быть плоской или «плиткой» с иконкой."""

    def __init__(self, master, text="", command=None, icon=None, stacked=False,
                 height=40, width=None, radius=12, bg="#FFFFFF", fg="#111827",
                 hover=None, outline="", parent_bg="white",
                 font=("Segoe UI", 10)):
        super().__init__(master, height=height, width=width or 10, bg=parent_bg,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.text, self.command, self.icon = text, command, icon
        self.stacked, self.radius, self.font = stacked, radius, font
        self.bg, self.fg, self.hover, self.outline = bg, fg, hover or bg, outline
        self._hovered = False

        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", lambda e: self._set_hover(True))
        self.bind("<Leave>", lambda e: self._set_hover(False))
        self.bind("<ButtonRelease-1>", self._on_click)

    def set_colors(self, bg, fg, hover=None, outline=""):
        self.bg, self.fg, self.hover, self.outline = bg, fg, hover or bg, outline
        self._draw()

    def _set_hover(self, value):
        self._hovered = value
        self._draw()

    def _on_click(self, event):
        if self.command and 0 <= event.x <= self.winfo_width() and 0 <= event.y <= self.winfo_height():
            self.command()

    def _draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 4 or h < 4:
            return
        fill = self.hover if self._hovered else self.bg
        _round_rect(self, 1, 1, w - 1, h - 1, self.radius, fill=fill,
                    outline=self.outline, width=1 if self.outline else 0)
        if self.stacked and self.icon:
            _draw_icon(self, self.icon, w / 2, h * 0.34, self.fg, fill)
            self.create_text(w / 2, h * 0.74, text=self.text, fill=self.fg,
                             font=self.font, justify="center")
        elif self.icon:
            _draw_icon(self, self.icon, w / 2, h / 2, self.fg, fill)
        else:
            self.create_text(w / 2, h / 2, text=self.text, fill=self.fg,
                             font=self.font, justify="center")


def _norm(s):
    """Нормализация для поиска: регистр, «ё» → «е», пробелы по краям."""
    return s.lower().replace("ё", "е").strip()


class StationPicker(tk.Frame):
    """Поле ввода станции с выпадающими подсказками (и режимом «точка на карте»)."""

    MAX_ROWS = 8

    def __init__(self, master, variable, stations, on_select=None,
                 on_clear_custom=None, font=("Segoe UI", 11)):
        super().__init__(master, bg="white")
        self.on_clear_custom = on_clear_custom
        self.custom_label = None              # текст, пока выбрана точка на карте
        self.variable = variable              # здесь хранится подтверждённая станция
        self.stations = sorted(stations)
        self.on_select = on_select
        self.font = font
        self._by_norm = {_norm(s): s for s in self.stations}

        self.text = tk.StringVar(value=variable.get())
        self.entry = tk.Entry(self, textvariable=self.text, font=font, relief="flat",
                              width=12, bg="white", highlightthickness=1,
                              highlightbackground="#D9DEE5", highlightcolor="#1A6DFF")
        self.entry.pack(fill="both", expand=True, ipady=5)

        # выпадающий список: рамка = список + полоса прокрутки (бегунок)
        self.popup = tk.Frame(self.winfo_toplevel(), bd=0, bg="#C9D1DC", padx=1, pady=1)
        self.scroll = ttk.Scrollbar(self.popup, orient="vertical", takefocus=0)
        self.lb = tk.Listbox(self.popup, font=font, activestyle="none",
                             height=self.MAX_ROWS, exportselection=False, relief="flat",
                             bd=0, highlightthickness=0, selectbackground="#DCEAFE",
                             selectforeground="#1A6DFF", fg="#111827", bg="white",
                             takefocus=0,
                             yscrollcommand=self.scroll.set)
        self.scroll.configure(command=self.lb.yview)
        self.lb.pack(side="left", fill="both", expand=True)
        self._items = []                         # реальные названия (в списке они с отступом)
        self._shown = False

        self.entry.bind("<FocusIn>", self._on_focus_in)
        self.entry.bind("<FocusOut>", lambda e: self._commit())
        self.entry.bind("<KeyRelease>", self._on_key)
        self.entry.bind("<Down>", lambda e: self._move(1))
        self.entry.bind("<Up>", lambda e: self._move(-1))
        self.entry.bind("<Return>", self._on_return)
        self.entry.bind("<Escape>", lambda e: self._close())
        # клик по списку обрабатываем сами, чтобы поле не теряло фокус
        self.lb.bind("<ButtonPress-1>", self._on_list_click)
        self.lb.bind("<Motion>", self._on_hover)
        self.winfo_toplevel().bind("<Button-1>", self._global_click, add="+")
        # если станцию поменяли программно, обновляем текст
        self.variable.trace_add("write", lambda *a: self.text.set(self.variable.get()))

    # ---- список подсказок
    def _matches(self, query):
        q = _norm(query)
        if not q:
            return self.stations
        return [s for s in self.stations if _norm(s).startswith(q)]   # только по началу названия

    def _show(self, items):
        if not items:
            self._close()
            return
        self._items = list(items)
        self.lb.delete(0, "end")
        for s in items:
            self.lb.insert("end", "  " + s)
        self.lb.selection_set(0)
        self.lb.configure(height=min(len(items), self.MAX_ROWS))
        if len(items) > self.MAX_ROWS:           # бегунок нужен только если список длинный
            self.scroll.pack(side="right", fill="y", padx=(0, 1))
        else:
            self.scroll.pack_forget()
        self.lb.yview_moveto(0)
        root = self.winfo_toplevel()
        x = self.entry.winfo_rootx() - root.winfo_rootx()
        y = self.entry.winfo_rooty() - root.winfo_rooty() + self.entry.winfo_height()
        self.popup.place(x=x, y=y, width=self.entry.winfo_width())
        self.popup.lift()
        self._shown = True

    def _close(self):
        if self._shown:
            self.popup.place_forget()
            self._shown = False

    # ---- события
    def _on_focus_in(self, e):
        self.entry.select_range(0, "end")      # список появится при вводе или по стрелке вниз

    def _on_key(self, e):
        if e.keysym in ("Up", "Down", "Return", "Escape", "Tab", "Left", "Right",
                        "Shift_L", "Shift_R", "Control_L", "Control_R"):
            return
        self._show(self._matches(self.text.get()))

    def _move(self, d):
        if not self._shown:
            self._show(self._matches(self.text.get()))
            return "break"
        cur = self.lb.curselection()
        i = (cur[0] if cur else -1) + d
        i = max(0, min(self.lb.size() - 1, i))
        self.lb.selection_clear(0, "end")
        self.lb.selection_set(i)
        self.lb.see(i)
        return "break"

    def _on_return(self, e):
        if self._shown and self.lb.curselection():
            self._choose(self._items[self.lb.curselection()[0]])
        else:
            self._commit()
        return "break"

    def _on_list_click(self, e):
        i = self.lb.nearest(e.y)
        if 0 <= i < len(self._items):
            self._choose(self._items[i])
        return "break"

    def _on_hover(self, e):
        i = self.lb.nearest(e.y)
        if 0 <= i < self.lb.size():
            self.lb.selection_clear(0, "end")
            self.lb.selection_set(i)

    def _global_click(self, e):
        if self._shown and e.widget not in (self.entry, self.lb, self.scroll):
            self._commit()
            self.winfo_toplevel().focus_set()

    # ---- режим «точка на карте»
    def set_custom(self, label):
        self.custom_label = label
        self.text.set(label)
        self.entry.icursor("end")
        self._close()

    def clear_custom(self):
        self.custom_label = None

    # ---- выбор значения
    def _choose(self, name):
        was_custom = self.custom_label is not None
        self.custom_label = None
        changed = was_custom or name != self.variable.get()
        if was_custom and self.on_clear_custom:
            self.on_clear_custom()
        self.variable.set(name)
        self.text.set(name)
        self.entry.icursor("end")
        self._close()
        if changed and self.on_select:
            self.on_select()

    def _commit(self):
        """Закрепляем введённое: точное совпадение / единственная подсказка, иначе откат."""
        typed = self.text.get()
        if self.custom_label is not None and typed == self.custom_label:
            self._close()                      # выбрана точка на карте — оставляем
            return
        name = self._by_norm.get(_norm(typed))
        if name is None:
            m = self._matches(typed) if typed.strip() else []
            name = m[0] if len(m) == 1 else self.variable.get()
        self._choose(name)


# ------------------------------------------------------------------
# 4. ИНТЕРФЕЙС
# ------------------------------------------------------------------

class MetroRouteApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Metro")
        self.geometry("1250x820")
        self.configure(bg="#EAF0F6")
        self.minsize(1000, 700)

        self.mode = tk.StringVar(value="fast")
        self.route = None

        # произвольные точки на карте (координаты схемы) и режим выбора
        self.from_point = None        # (x, y) или None
        self.to_point = None
        self.pick_target = None       # "from" / "to" — ждём клика по карте

        # масштабирование / перемещение карты
        self.zoom = 1.0
        self.pan = [0.0, 0.0]
        self._fit_zoom = 1.0
        self._view_touched = False
        self._drag = None
        self._fonts = {}

        self._build_sidebar()
        self._build_map()
        self.draw_map()

    # ---------------------------------------------------------- UI
    def _build_sidebar(self):
        sidebar = tk.Frame(self, bg="white", width=360)
        sidebar.pack(side="right", fill="y")
        sidebar.pack_propagate(False)

        pad = {"padx": 24}

        header = tk.Frame(sidebar, bg="white")
        header.pack(fill="x", pady=(16, 20), **pad)
        # круглый логотип
        logo = tk.Canvas(header, width=40, height=40, bg="white",
                         highlightthickness=0, bd=0)
        logo.create_oval(1, 1, 39, 39, fill="#E63946", outline="")
        logo.create_text(20, 20, text="M", fill="white", font=("Segoe UI", 16, "bold"))
        logo.pack(side="left")
        tk.Label(header, text="Metro", bg="white",
                 font=("Segoe UI", 18, "bold")).pack(side="left", padx=10)

        # «Настройки» — в самом верхнем правом углу боковой панели
        RoundedButton(header, text="⚙", command=self.open_settings,
                      width=44, height=44, radius=12,
                      bg="white", hover="#F3F4F6", outline="#D9DEE5", fg="#374151",
                      parent_bg="white",
                      font=("Segoe UI Symbol", 22)).pack(side="right")

        pick = tk.Frame(sidebar, bg="white")
        pick.pack(fill="x", pady=(0, 16), **pad)
        pick.columnconfigure(0, weight=1)

        self.pin_btns = {}

        tk.Label(pick, text="Откуда", bg="white", fg="#6B7280",
                 font=("Segoe UI", 9)).grid(row=0, column=0, sticky="w")
        from_row = tk.Frame(pick, bg="white")
        from_row.grid(row=1, column=0, sticky="ew", pady=(2, 6))
        tk.Label(from_row, text="●", fg="#2E7BF6", bg="white",
                 font=("Segoe UI", 12)).pack(side="left")
        self.pin_btns["from"] = RoundedButton(
            from_row, icon="pin", command=lambda: self.toggle_pick("from"),
            width=38, height=10, radius=10, bg="white", hover="#F3F4F6",
            outline="#D9DEE5", fg="#6B7280")
        self.pin_btns["from"].pack(side="right", fill="y")   # высота = высоте поля
        self.from_var = tk.StringVar(value=sorted(STATIONS)[0])
        self.from_box = StationPicker(from_row, self.from_var, STATIONS,
                                      on_select=self.on_stations_changed,
                                      on_clear_custom=lambda: self._clear_point("from"))
        self.from_box.pack(side="left", fill="both", expand=True, padx=8)

        tk.Label(pick, text="Куда", bg="white", fg="#6B7280",
                 font=("Segoe UI", 9)).grid(row=2, column=0, sticky="w")
        to_row = tk.Frame(pick, bg="white")
        to_row.grid(row=3, column=0, sticky="ew", pady=(2, 0))
        tk.Label(to_row, text="●", fg="#E63946", bg="white",
                 font=("Segoe UI", 12)).pack(side="left")
        self.pin_btns["to"] = RoundedButton(
            to_row, icon="pin", command=lambda: self.toggle_pick("to"),
            width=38, height=10, radius=10, bg="white", hover="#F3F4F6",
            outline="#D9DEE5", fg="#6B7280")
        self.pin_btns["to"].pack(side="right", fill="y")     # высота = высоте поля
        self.to_var = tk.StringVar(value=sorted(STATIONS)[-1])
        self.to_box = StationPicker(to_row, self.to_var, STATIONS,
                                    on_select=self.on_stations_changed,
                                    on_clear_custom=lambda: self._clear_point("to"))
        self.to_box.pack(side="left", fill="both", expand=True, padx=8)
        self._refresh_pin_buttons()

        action_row = tk.Frame(sidebar, bg="white")
        action_row.pack(fill="x", pady=(4, 16), **pad)

        # компактная кнопка сброса — справа (пакуем первой, чтобы она не вытеснялась)
        reset_btn = RoundedButton(action_row, text="Сбросить маршрут",
                                  command=self.reset_route,
                                  width=150, height=50, radius=18,
                                  bg="#F3F4F6", hover="#E9EBEF", fg="#4B5563",
                                  font=("Segoe UI", 10, "bold"))
        reset_btn.pack(side="right", padx=(8, 0))

        # кнопка поиска — слева, занимает всю оставшуюся ширину
        find_btn = RoundedButton(action_row, text="Найти маршрут", command=self.search_route,
                                 height=50, radius=18, bg="#1A6DFF", hover="#0F5AE0",
                                 fg="white", font=("Segoe UI", 12, "bold"))
        find_btn.pack(side="left", fill="x", expand=True)

        filters = tk.Frame(sidebar, bg="white")
        filters.pack(fill="x", pady=(0, 16), **pad)
        self.filter_btns = {}
        items = (("fast", "Быстрее", "clock"),
                 ("stops", "Меньше\nостановок", "bus"),
                 ("cheap", "Дешевле", "coin"))
        for i, (key, label, icon) in enumerate(items):
            filters.columnconfigure(i, weight=1, uniform="flt")
            b = RoundedButton(filters, text=label, icon=icon, stacked=True,
                              command=lambda k=key: self.set_mode(k),
                              height=84, radius=10, font=("Segoe UI", 9))
            b.grid(row=0, column=i, sticky="ew", padx=3)
            self.filter_btns[key] = b
        self._refresh_filter_buttons()

        self.result_frame = tk.Frame(sidebar, bg="white")
        self.result_frame.pack(fill="both", expand=True, **pad)

    def _build_map(self):
        map_wrap = tk.Frame(self, bg="#EAF0F6")
        map_wrap.pack(side="left", fill="both", expand=True)

        self.canvas = tk.Canvas(map_wrap, bg="#DCEAF5", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=20, pady=20)
        self.canvas.bind("<Configure>", lambda e: self.draw_map())
        self.canvas.bind("<ButtonPress-1>", self._drag_start)
        self.canvas.bind("<B1-Motion>", self._drag_move)
        self.canvas.bind("<ButtonRelease-1>", self._drag_end)
        self.canvas.bind("<MouseWheel>", lambda e: self._zoom_at(e.x, e.y, 1.15 if e.delta > 0 else 1 / 1.15))
        self.canvas.bind("<Button-4>", lambda e: self._zoom_at(e.x, e.y, 1.15))
        self.canvas.bind("<Button-5>", lambda e: self._zoom_at(e.x, e.y, 1 / 1.15))
        self.canvas.bind("<Double-Button-1>", lambda e: self._reset_view())

    # ------------------------------------------------------ настройки
    def open_settings(self):
        """Окно настроек: алгоритм, время пересадки и стоянки, стоимость проезда (горизонтально)."""
        win = tk.Toplevel(self)
        win.title("Настройки")
        win.configure(bg="white")
        win.resizable(False, False)
        win.transient(self)

        def title(parent, text, hint=None, wrap=260):
            tk.Label(parent, text=text, bg="white",
                     font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(0, 2))
            if hint:
                tk.Label(parent, text=hint, bg="white", fg="#6B7280", justify="left",
                         wraplength=wrap, font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 8))

        body = tk.Frame(win, bg="white")
        body.pack(fill="both", padx=24, pady=(20, 0))

        # ---- колонка 1: алгоритм
        col1 = tk.Frame(body, bg="white")
        col1.grid(row=0, column=0, sticky="n")
        title(col1, "Алгоритм поиска", "Каким способом будет строиться маршрут.")
        algo_var = tk.StringVar(value=SETTINGS["algorithm"])
        for key, info in ALGORITHMS.items():
            tk.Radiobutton(col1, text=info["name"], value=key, variable=algo_var,
                           bg="white", activebackground="white", anchor="w",
                           font=("Segoe UI", 10), cursor="hand2").pack(fill="x")
            if info["desc"]:
                tk.Label(col1, text=info["desc"], bg="white", fg="#6B7280",
                         justify="left", wraplength=260,
                         font=("Segoe UI", 9)).pack(anchor="w", padx=22, pady=(0, 6))

        ttk.Separator(body, orient="vertical").grid(row=0, column=1, sticky="ns", padx=20)

        # ---- колонка 2: время пересадки и время стоянки
        col2 = tk.Frame(body, bg="white")
        col2.grid(row=0, column=2, sticky="n")

        def spin_row(parent, label, value, to, increment):
            row = tk.Frame(parent, bg="white")
            row.pack(fill="x", pady=4)
            tk.Label(row, text=label, bg="white", anchor="w",
                     font=("Segoe UI", 10)).pack(side="left")
            tk.Label(row, text="мин", bg="white", fg="#6B7280",
                     font=("Segoe UI", 10)).pack(side="right")
            var = tk.StringVar(value=f"{value:g}")
            ttk.Spinbox(row, from_=0, to=to, increment=increment, width=6,
                        textvariable=var, justify="right",
                        font=("Segoe UI", 10)).pack(side="right", padx=(8, 4))
            return var

        title(col2, "Время пересадки",
              "Сколько минут занимает любая пересадка между линиями.", wrap=300)
        transfer_var = spin_row(col2, "Одна пересадка", SETTINGS["transfer_min"], 120, 0.5)

        tk.Frame(col2, bg="white", height=16).pack()
        title(col2, "Время стоянки",
              "Сколько минут поезд стоит на каждой промежуточной станции.", wrap=300)
        dwell_var = spin_row(col2, "Стоянка на станции", SETTINGS["dwell_min"], 10, 0.5)

        ttk.Separator(body, orient="vertical").grid(row=0, column=3, sticky="ns", padx=20)

        # ---- колонка 3: стоимость, в два столбца
        col3 = tk.Frame(body, bg="white")
        col3.grid(row=0, column=4, sticky="n")
        title(col3, "Стоимость проезда", "Разовая плата за проезд по одной линии. "
                                         "При пересадке плата взимается снова.", wrap=420)
        grid = tk.Frame(col3, bg="white")
        grid.pack(anchor="w")

        vars_ = {}
        rows = (len(LINE_NAMES) + 1) // 2
        for i, key in enumerate(LINE_NAMES):
            r, c0 = i % rows, (i // rows) * 4
            if c0:
                grid.columnconfigure(c0 - 1, minsize=24)
            tk.Label(grid, text="●", fg=LINE_COLORS[key], bg="white",
                     font=("Segoe UI", 13)).grid(row=r, column=c0, pady=2)
            tk.Label(grid, text=COLOR_NAMES[key], bg="white", anchor="w", width=16,
                     font=("Segoe UI", 10)).grid(row=r, column=c0 + 1, sticky="w", padx=6)
            var = tk.StringVar(value=str(LINE_FARES[key]))
            ttk.Spinbox(grid, from_=0, to=10000, increment=1, width=6,
                        textvariable=var, justify="right",
                        font=("Segoe UI", 10)).grid(row=r, column=c0 + 2, padx=(4, 2))
            tk.Label(grid, text="¥", bg="white", fg="#6B7280",
                     font=("Segoe UI", 12)).grid(row=r, column=c0 + 3)
            vars_[key] = var

        def read_int(var, what):
            try:
                val = int(var.get().strip())
                if val < 0:
                    raise ValueError
                return val
            except ValueError:
                messagebox.showerror("Metro",
                                     f"{what}: введите целое неотрицательное число.",
                                     parent=win)
                return None

        def read_float(var, what):
            try:
                val = float(var.get().strip().replace(",", "."))
                if val < 0:
                    raise ValueError
                return val
            except ValueError:
                messagebox.showerror("Metro",
                                     f"{what}: введите неотрицательное число минут.",
                                     parent=win)
                return None

        def on_save():
            transfer = read_float(transfer_var, "Время пересадки")
            if transfer is None:
                return
            dwell = read_float(dwell_var, "Время стоянки")
            if dwell is None:
                return
            new = {}
            for key, var in vars_.items():
                val = read_int(var, f"{COLOR_NAMES[key]} линия")
                if val is None:
                    return
                new[key] = val
            LINE_FARES.update(new)
            SETTINGS["transfer_min"] = transfer
            SETTINGS["dwell_min"] = dwell
            SETTINGS["algorithm"] = algo_var.get()
            save_settings()
            win.destroy()
            if self.route is not None:
                self.search_route()

        def on_reset():
            algo_var.set(DEFAULT_ALGORITHM)
            transfer_var.set(f"{DEFAULT_TRANSFER_MIN:g}")
            dwell_var.set(f"{DEFAULT_DWELL_MIN:g}")
            for key, var in vars_.items():
                var.set(str(DEFAULT_FARES[key]))

        btns = tk.Frame(win, bg="white")
        btns.pack(fill="x", padx=24, pady=20)
        RoundedButton(btns, text="Сохранить", command=on_save, width=130, height=40, radius=12,
                      bg="#1A6DFF", hover="#0F5AE0", fg="white",
                      font=("Segoe UI", 10, "bold")).pack(side="right", padx=(8, 0))
        RoundedButton(btns, text="Отмена", command=win.destroy, width=110, height=40, radius=12,
                      bg="#F3F4F6", hover="#E9EBEF", fg="#4B5563").pack(side="right", padx=8)
        RoundedButton(btns, text="По умолчанию", command=on_reset, width=140, height=40, radius=12,
                      bg="#F3F4F6", hover="#E9EBEF", fg="#4B5563").pack(side="left")

        win.update_idletasks()
        x = self.winfo_rootx() + (self.winfo_width() - win.winfo_width()) // 2
        y = self.winfo_rooty() + (self.winfo_height() - win.winfo_height()) // 2
        win.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        win.grab_set()

    # ------------------------------------------- точки на карте («моё местоположение»)
    def toggle_pick(self, which):
        if self.pick_target == which:
            self._cancel_pick()
            return
        self.pick_target = which
        self.canvas.configure(cursor="crosshair")
        self._refresh_pin_buttons()
        self.draw_map()

    def _cancel_pick(self):
        if self.pick_target is None:
            return
        self.pick_target = None
        self.canvas.configure(cursor="")
        self._refresh_pin_buttons()
        self.draw_map()

    def _clear_point(self, which):
        if which == "from":
            self.from_point = None
        else:
            self.to_point = None
        self._refresh_pin_buttons()

    def _place_point(self, which, wx, wy):
        p = (min(max(wx, 0), WORLD_W), min(max(wy, 0), WORLD_H))
        if which == "from":
            self.from_point = p
            self.from_box.set_custom(CUSTOM_LABEL)
        else:
            self.to_point = p
            self.to_box.set_custom(CUSTOM_LABEL)
        self.pick_target = None
        self.canvas.configure(cursor="")
        self._refresh_pin_buttons()
        self.on_stations_changed()            # сбросит старый маршрут и перерисует карту

    def _refresh_pin_buttons(self):
        for which, btn in self.pin_btns.items():
            pt = self.from_point if which == "from" else self.to_point
            if which == "from":
                col, light, hov, outl = "#2E7BF6", "#DCEAFE", "#CFE1FD", "#C4DAFB"
            else:
                col, light, hov, outl = "#E63946", "#FDE2E4", "#FBD0D4", "#F5B5BB"
            if self.pick_target == which or pt is not None:
                btn.set_colors(bg=light, fg=col, hover=hov, outline=outl)
            else:
                btn.set_colors(bg="white", fg="#6B7280", hover="#F3F4F6", outline="#D9DEE5")

    # ------------------------------------------------------- логика
    def reset_route(self):
        """Сбрасывает найденный маршрут и точки на карте: выбранные станции, алгоритм,
        критерий, настройки времени и положение/масштаб карты остаются как были."""
        self.pick_target = None
        self.canvas.configure(cursor="")
        self.from_point = self.to_point = None
        for box, var in ((self.from_box, self.from_var), (self.to_box, self.to_var)):
            box.clear_custom()
            box.text.set(var.get())            # в поле снова показываем станцию
        self._refresh_pin_buttons()
        self.route = None
        for w in self.result_frame.winfo_children():
            w.destroy()
        self.draw_map()

    def on_stations_changed(self, event=None):
        """При выборе станции подсвечиваем её на карте; старый маршрут сбрасываем."""
        self.route = None
        for w in self.result_frame.winfo_children():
            w.destroy()
        self.draw_map()

    def set_mode(self, key):
        self.mode.set(key)
        self._refresh_filter_buttons()
        if self.route is not None:
            self.search_route()

    def _refresh_filter_buttons(self):
        for key, btn in self.filter_btns.items():
            if key == self.mode.get():
                btn.set_colors(bg="#DCEAFE", fg="#1A6DFF", hover="#CFE1FD", outline="#C4DAFB")
            else:
                btn.set_colors(bg="#F3F4F6", fg="#4B5563", hover="#E9EBEF")

    def _endpoint(self, which):
        """(станция, точка или None): для произвольной точки берём ближайшую станцию."""
        pt, var = ((self.from_point, self.from_var) if which == "from"
                   else (self.to_point, self.to_var))
        return (nearest_station(pt), pt) if pt else (var.get(), None)

    def search_route(self):
        start, s_pt = self._endpoint("from")
        end, e_pt = self._endpoint("to")
        if not start or not end:
            return
        if start == end and not (s_pt or e_pt):
            messagebox.showinfo("Metro", "Выберите разные станции отправления и назначения.")
            return

        result = find_route(start, end, self.mode.get())
        if result is not None:
            walk = []                      # (вид, из, в, минут, подпись)
            if s_pt:
                m = max(1, round(math.dist(s_pt, STATIONS[start]) / WALK_SPEED))
                walk.append(("start", s_pt, STATIONS[start], m,
                             f"Пешком до станции {start} · {m} мин"))
            if e_pt:
                m = max(1, round(math.dist(STATIONS[end], e_pt) / WALK_SPEED))
                walk.append(("end", STATIONS[end], e_pt, m,
                             f"Пешком от станции {end} до точки · {m} мин"))
            result["walk"] = walk
            result["time"] += sum(w[3] for w in walk)
        self.route = result
        self.draw_map()
        self._render_result_panel(start, end, result)

    def _render_result_panel(self, start, end, result):
        for w in self.result_frame.winfo_children():
            w.destroy()

        if result is None:
            tk.Label(self.result_frame, text="Маршрут не найден", fg="#E63946",
                     bg="white", font=("Segoe UI", 10)).pack(anchor="w", pady=8)
            return

        n = result["transfers"]
        if n == 0:
            tr = "без пересадок"
        elif n == 1:
            tr = "1 пересадка"
        elif n < 5:
            tr = f"{n} пересадки"
        else:
            tr = f"{n} пересадок"
        tk.Label(self.result_frame,
                 text=f"{result['time']} мин · {tr} · {result['price']} ¥",
                 bg="white", font=("Segoe UI", 13, "bold"),
                 wraplength=290, justify="left").pack(anchor="w", pady=(6, 10))

        # один участок = одна линия без пересадок
        segments = []
        for (u, v, line, w) in result["legs"]:
            if segments and segments[-1]["line"] == line:
                segments[-1]["stops"].append(v)
            else:
                segments.append({"line": line, "stops": [u, v]})

        walk = result.get("walk", [])
        for kind, _a, _b, _m, text in walk:
            if kind == "start":
                tk.Label(self.result_frame, text="┄ " + text, bg="white", fg="#374151",
                         font=("Segoe UI", 9), wraplength=290, justify="left").pack(anchor="w")

        list_frame = tk.Frame(self.result_frame, bg="white")
        list_frame.pack(fill="x")
        for i, seg in enumerate(segments):
            if i > 0:
                tk.Label(list_frame, text="⟳ пересадка", bg="white", fg="#F5B400",
                         font=("Segoe UI", 8, "italic")).pack(anchor="w", padx=22)
            row = tk.Frame(list_frame, bg="white")
            row.pack(fill="x", pady=3)
            tk.Label(row, text="●", fg=LINE_COLORS[seg["line"]], bg="white",
                     font=("Segoe UI", 13)).pack(side="left", anchor="n")
            info = tk.Frame(row, bg="white")
            info.pack(side="left", padx=6)
            tk.Label(info, text=f"{seg['stops'][0]} → {seg['stops'][-1]}", bg="white",
                     font=("Segoe UI", 10, "bold"), wraplength=240, justify="left").pack(anchor="w")
            tk.Label(info, text=f"{LINE_NAMES[seg['line']]} · {len(seg['stops']) - 1} ост. · "
                                f"{LINE_FARES[seg['line']]} ¥",
                     bg="white", fg="#6B7280", font=("Segoe UI", 9)).pack(anchor="w")

        for kind, _a, _b, _m, text in walk:
            if kind == "end":
                tk.Label(self.result_frame, text="┄ " + text, bg="white", fg="#374151",
                         font=("Segoe UI", 9), wraplength=290,
                         justify="left").pack(anchor="w", pady=(4, 0))

    # ------------------------------------------- масштаб и перемещение
    def _fit_view(self, cw, ch):
        k = min(cw / WORLD_W, ch / WORLD_H)
        self.zoom = k
        self.pan = [(cw - WORLD_W * k) / 2, (ch - WORLD_H * k) / 2]

    def _reset_view(self):
        self._view_touched = False
        self.draw_map()

    def _zoom_at(self, mx, my, factor):
        new = min(max(self.zoom * factor, self._fit_zoom * 0.9), self._fit_zoom * 8)
        ratio = new / self.zoom
        self.pan = [mx - (mx - self.pan[0]) * ratio, my - (my - self.pan[1]) * ratio]
        self.zoom = new
        self._view_touched = True
        self.draw_map()

    def _drag_start(self, e):
        self._drag = (e.x, e.y, self.pan[0], self.pan[1])

    def _drag_move(self, e):
        if not self._drag:
            return
        x0, y0, px, py = self._drag
        self.pan = [px + e.x - x0, py + e.y - y0]
        self._view_touched = True
        self.draw_map()

    def _drag_end(self, e):
        d, self._drag = self._drag, None
        # короткий клик (не перетаскивание) в режиме выбора точки
        if d and self.pick_target and math.hypot(e.x - d[0], e.y - d[1]) < 5:
            self._place_point(self.pick_target,
                              (d[0] - d[2]) / self.zoom, (d[1] - d[3]) / self.zoom)

    def _font(self, size, weight="normal"):
        key = (size, weight)
        if key not in self._fonts:
            self._fonts[key] = tkfont.Font(family="Segoe UI", size=size, weight=weight)
        return self._fonts[key]

    # ---------------------------------------------------- отрисовка
    def draw_map(self):
        c = self.canvas
        c.delete("all")
        cw = max(c.winfo_width(), 600)
        ch = max(c.winfo_height(), 500)
        self._fit_zoom = min(cw / WORLD_W, ch / WORLD_H)
        if not self._view_touched:
            self._fit_view(cw, ch)

        k = self.zoom
        ox, oy = self.pan
        s = min(max(k * 1.5, 0.8), 2.4)          # множитель размеров значков
        bg = "#DCEAF5"
        GRAY_LINE, GRAY_RING, GRAY_TEXT = "#CDD3DA", "#C3CAD2", "#AEB6C0"

        has_route = bool(self.route and (self.route["legs"] or self.route.get("walk")))

        def pt(name):
            x, y = STATIONS[name]
            return x * k + ox, y * k + oy

        def flat(path):
            out = []
            for x, y in path:
                out += [x * k + ox, y * k + oy]
            return out

        # линии: при выбранном маршруте всё остальное серое
        for a, b, t, ln in EDGES:
            c.create_line(*flat(EDGE_PATHS[(a, b, ln)]),
                          fill=GRAY_LINE if has_route else LINE_COLORS[ln],
                          width=6 * s, capstyle="round", joinstyle="round")

        # выделенный маршрут поверх (в своих цветах)
        route_stations = set()
        station_color = {}                              # станция -> цвет линии маршрута
        if has_route:
            route_stations = set(self.route["stations"])
            runs = []                                   # [(точки, линия)]
            for (u, v, line, w) in self.route["legs"]:
                seg = flat(EDGE_PATHS[(u, v, line)])
                station_color.setdefault(u, LINE_COLORS[line])
                station_color.setdefault(v, LINE_COLORS[line])
                if runs and runs[-1][1] == line:
                    runs[-1][0].extend(seg[2:])
                else:
                    runs.append((seg, line))
            for pts, line in runs:
                c.create_line(*pts, fill=LINE_COLORS[line], width=6 * s,
                              capstyle="round", joinstyle="round")
            # пешие участки «точка ↔ станция» — чёрным пунктиром
            for _kind, p1, p2, _m, _t in self.route.get("walk", []):
                c.create_line(p1[0] * k + ox, p1[1] * k + oy, p2[0] * k + ox, p2[1] * k + oy,
                              fill="#111827", width=max(2, 2.5 * s), dash=(5, 16),
                              capstyle="round")

        # станции (если конец маршрута задан точкой на карте — станцию не выделяем как «выбранную»)
        start = self.from_var.get() if self.from_point is None else None
        end = self.to_var.get() if self.to_point is None else None
        entries = []                # (приоритет, имя, x, y, r)
        node_rects = []
        for name in STATIONS:
            x, y = pt(name)
            lines_here = STATION_LINES[name]
            on_route = name in route_stations
            selected = name in (start, end)

            if selected:
                r = 8.55 * s
                fill, halo = ("#2E7BF6", "#BBD3FD") if name == start else ("#E63946", "#F9C0C5")
                c.create_oval(x - r - 6.84 * s, y - r - 6.84 * s, x + r + 6.84 * s, y + r + 6.84 * s,
                              fill=halo, outline="")
                c.create_oval(x - r, y - r, x + r, y + r, fill=fill, outline="white", width=3)
                prio = 0
            elif has_route:
                if on_route:
                    col = station_color.get(name, "#111827")
                    r = 6 * s
                    c.create_oval(x - r, y - r, x + r, y + r, fill="white",
                                  outline=col, width=2.5)
                    prio = 1
                else:
                    r = (6.5 if len(lines_here) > 1 else 4.5) * s
                    c.create_oval(x - r, y - r, x + r, y + r, fill="white",
                                  outline=GRAY_RING, width=2)
                    prio = 4
            elif len(lines_here) > 1:
                r = 7.5 * s
                c.create_oval(x - r, y - r, x + r, y + r, fill="white",
                              outline="#111827", width=2.5)
                prio = 2
            else:
                r = 4.5 * s
                c.create_oval(x - r, y - r, x + r, y + r, fill="white",
                              outline=LINE_COLORS[next(iter(lines_here))], width=2.5)
                prio = 3
            entries.append((prio, name, x, y, r))
            node_rects.append((x - r - 1, y - r - 1, x + r + 1, y + r + 1))

        # подписи: подбираем место без наложений, важные станции подписываем всегда
        fs = 8 if s < 1.3 else 9
        placed = []

        # произвольные точки «Откуда» / «Куда»
        for which, p in (("from", self.from_point), ("to", self.to_point)):
            if p is None:
                continue
            x, y = p[0] * k + ox, p[1] * k + oy
            r = 8.55 * s
            fill, halo = ("#2E7BF6", "#BBD3FD") if which == "from" else ("#E63946", "#F9C0C5")
            c.create_oval(x - r - 6.84 * s, y - r - 6.84 * s, x + r + 6.84 * s, y + r + 6.84 * s,
                          fill=halo, outline="")
            c.create_oval(x - r, y - r, x + r, y + r, fill=fill, outline="white", width=3)
            node_rects.append((x - r - 1, y - r - 1, x + r + 1, y + r + 1))
            lab = "Откуда" if which == "from" else "Куда"
            f = self._font(fs + 1, "bold")
            tw, th = f.measure(lab), f.metrics("linespace")
            ty = y - r - 10 * s
            placed.append((x - tw / 2, ty - th, x + tw / 2, ty))
            c.create_text(x, ty, text=lab, font=f, anchor="s", fill=fill)

        def hit(rc, others):
            return any(not (rc[2] <= o[0] or rc[0] >= o[2] or rc[3] <= o[1] or rc[1] >= o[3])
                       for o in others)

        for prio, name, x, y, r in sorted(entries, key=lambda e: e[0]):
            if has_route:
                important = prio <= 1
            else:
                important = prio <= 2 or name in (start, end)
            font = self._font(fs + 1 if prio == 0 else fs, "bold" if important else "normal")
            tw, th = font.measure(name), font.metrics("linespace")
            g = r + 3
            options = [
                ("s", (x - tw / 2, y - g - th, x + tw / 2, y - g), (x, y - g)),
                ("n", (x - tw / 2, y + g, x + tw / 2, y + g + th), (x, y + g)),
                ("w", (x + g, y - th / 2, x + g + tw, y + th / 2), (x + g, y)),
                ("e", (x - g - tw, y - th / 2, x - g, y + th / 2), (x - g, y)),
            ]
            chosen = None
            for anchor, rc, pos in options:
                if not hit(rc, placed) and not hit(rc, node_rects):
                    chosen = (anchor, rc, pos)
                    break
            if chosen is None:
                if not important:
                    continue
                chosen = options[0]
            anchor, rc, pos = chosen
            placed.append(rc)

            if has_route and not important:             # блёклые подписи без подложки
                c.create_text(pos[0], pos[1], text=name, font=font, anchor=anchor,
                              fill=GRAY_TEXT)
                continue
            if prio != 0:
                for dx, dy in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
                    c.create_text(pos[0] + dx, pos[1] + dy, text=name, font=font,
                                  fill=bg, anchor=anchor)
            c.create_text(pos[0], pos[1], text=name, font=font, anchor=anchor,
                          fill="#111827" if important else "#1F2937")


if __name__ == "__main__":
    app = MetroRouteApp()
    app.mainloop()